var config = {
    map: { 
    	'*': {           
            'ks_owlcarousel': "Kashyap_Banners/js/owlcarousel"
        }
    },   
    shim: {
        'ks_owlcarousel': {
            deps: ['jquery']
        }
    }
};